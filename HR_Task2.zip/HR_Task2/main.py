import csv
import json
import os
import requests
from dotenv import load_dotenv

# Load environment variables from .env
load_dotenv()
API_KEY = os.getenv("API_KEY")  # Loaded as required; JSONPlaceholder needs no API key.


# -----------------------------------
# 1. Read employees.csv using DictReader
# -----------------------------------
employees = []
with open("employees.csv", "r", newline="", encoding="utf-8") as file:
    reader = csv.DictReader(file)
    for row in reader:
        row["salary"] = int(row["salary"])
        employees.append(row)

# -----------------------------------
# 2. Write employees.json
# -----------------------------------
with open("employees.json", "w", encoding="utf-8") as file:
    json.dump(employees, file, indent=4)

# -----------------------------------
# 3. Filter high earners (salary above 50000)
# -----------------------------------
high_earners = [employee for employee in employees if employee["salary"] > 50000]

with open("high_earners.csv", "w", newline="", encoding="utf-8") as file:
    writer = csv.DictWriter(file, fieldnames=employees[0].keys())
    writer.writeheader()
    writer.writerows(high_earners)

print(f"Rows read: {len(employees)} | High earners: {len(high_earners)}")

# -----------------------------------
# 4. Fetch API users, print first 3, parse nested fields with .get()
# -----------------------------------
users_url = "https://jsonplaceholder.typicode.com/users"
try:
    response = requests.get(users_url, timeout=5)
    response.raise_for_status()
    users = response.json()

    for user in users:
        address = user.get("address", {})
        geo = address.get("geo", {})
        user["city"] = address.get("city")
        user["latitude"] = geo.get("lat")
        user["longitude"] = geo.get("lng")

    for user in users[:3]:
        print(f'{user["id"]} - {user["name"]} - {user["email"]}')

    with open("users.json", "w", encoding="utf-8") as file:
        json.dump(users, file, indent=4)

except requests.exceptions.Timeout:
    print("Users request timed out")
except requests.exceptions.ConnectionError:
    print("Connection error while fetching users")
except requests.exceptions.HTTPError as error:
    print(f"HTTP error while fetching users: {error}")
except requests.exceptions.RequestException as error:
    print(f"Request error while fetching users: {error}")

# -----------------------------------
# 5. Check the required 404 endpoint
# -----------------------------------
try:
    bad_url = "https://jsonplaceholder.typicode.com/users/9999"
    bad_response = requests.get(bad_url, timeout=5)
    if bad_response.status_code == 404:
        print("/users/9999 -> 404 Not found")
    else:
        bad_response.raise_for_status()
        print(f"/users/9999 -> {bad_response.status_code}")
except requests.exceptions.Timeout:
    print("404 check timed out")
except requests.exceptions.ConnectionError:
    print("Connection error during 404 check")
except requests.exceptions.HTTPError as error:
    print(f"HTTP error during 404 check: {error}")
except requests.exceptions.RequestException as error:
    print(f"Request error during 404 check: {error}")

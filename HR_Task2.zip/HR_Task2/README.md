# HR Task 2 — Files, APIs and Environment

## Files
- `employees.csv`: input employee records from Task 1
- `main.py`: reads CSV, writes JSON/CSV outputs, fetches API users, handles request errors
- `requirements.txt`: Python dependencies
- `.env`: local API_KEY value (kept out of Git)
- `.gitignore`: excludes `.env`, virtual environment and cache files

## Setup in VS Code (Windows)
1. Open this folder in VS Code.
2. Open Terminal → New Terminal.
3. Create a virtual environment: `python -m venv venv`
4. Activate it: `venv\\Scripts\\activate`
5. Install dependencies: `pip install -r requirements.txt`
6. Run: `python main.py`

The script creates `employees.json`, `high_earners.csv`, and `users.json` in this folder.
